/* ## Ejercicio 3
1. Crea una tabla llamada "Productos" con las columnas: "id" (entero, clave primaria), "nombre" (texto) y "precio" (numérico) */ 
CREATE TABLE Productos(
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    precio NUMERIC(10, 2)
)

/* 2. Inserta al menos cinco registros en la tabla "Productos" */
INSERT INTO Productos (nombre, precio)
VALUES  ('Camiseta', 15.99),
        ('Pantalones', 29.95),
        ('Falda', 20),
        ('Jersey', 35.99),
        ('Chaqueta', 45.95)

/* 3. Actualiza el precio de un producto en la tabla "Productos" */
UPDATE Productos 
SET precio = 19.99
WHERE nombre = 'Camiseta'

/* 4. Elimina un producto de la tabla "Productos" */
DELETE FROM Productos
WHERE id = 3

/* 5. Realiza una consulta que muestre los nombres de los usuarios junto con los nombres de los productos que han comprado (utiliza un INNER JOIN con la tabla "Productos") */
SELECT 
  Usuarios.nombre  AS nombre_usuario,
  Productos.nombre AS nombre_producto
FROM Productos
INNER JOIN Usuarios 
ON Productos.nombre = Usuarios.nombre
