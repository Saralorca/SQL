/* ## Ejercicio 4
1. Crea una tabla llamada "Pedidos" con las columnas: "id" (entero, clave primaria),"id_usuario" (entero, clave foránea de la tabla "Usuarios") y "id_producto" (entero, clave foránea de la tabla "Productos"). */ 
CREATE TABLE Pedidos (
    id SERIAL PRIMARY KEY,
    id_usuario INTEGER NOT NULL,
    id_producto INTEGER NOT NULL
    CONSTRAINT fk_id_usuario FOREIGN KEY (id_usuario) REFERENCES Usuarios (id)
    CONSTRAINT fk_id_producto FOREIGN KEY (id_producto) REFERENCES Productos (id)
)

/* 2. Inserta al menos tres registros en la tabla "Pedidos" que relacionen usuarios con productos.*/
INSERT INTO public.Pedidos (id_usuario, id_producto)
VALUES 
  (1, 5),
  (4, 4),
  (4, 1)

/* 3. Realiza una consulta que muestre los nombres de los usuarios y los nombres de los productos que han comprado, incluidos aquellos que no han realizado ningún pedido (utiliza LEFT JOIN y COALESCE).*/
SELECT 
  Usuarios.nombre AS nombre_usuario,
  COALESCE(Productos.nombre, 'No ha realizado ningún pedido') AS nombre_producto
FROM Usuarios
LEFT JOIN Pedidos
ON Usuarios.id = Pedidos.id_usuario
LEFT JOIN Productos
ON Pedidos.id_producto = Productos.id

/* 4. Realiza una consulta que muestre los nombres de los usuarios que han realizado un pedido, pero también los que no han realizado ningún pedido (utiliza LEFT JOIN)*/
SELECT  
  Usuarios.nombre AS nombre_usuario
FROM Usuarios
LEFT JOIN Pedidos
ON Usuarios.id = Pedidos.id_usuario

/* 5. Agrega una nueva columna llamada "cantidad" a la tabla "Pedidos" y actualiza los registros existentes con un valor (utiliza ALTER TABLE UPDATE */
UPDATE Pedidos
SET cantidad = 1
