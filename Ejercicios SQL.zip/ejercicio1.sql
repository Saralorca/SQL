/* ## Ejercicio 1
1. Crear una tabla llamada 'Clientes' con las columnas: id (entero, clave primaria), nombre (texto) y email (texto). */
CREATE TABLE Clientes(
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    email VARCHAR(255)
)

/*  2. Insertar un nuevo cliente en la tabla "Clientes" con id=1, nombre="Juan" y email="juan@example.com". */
INSERT INTO public.Clientes (nombre, email)
VALUES ('Juan', 'juan@example.com')

/* 3. Actualizar el email del cliente con id=1 a "juan@gmail.com"*/
UPDATE public.Clientes
SET email = 'juan@gmail.com'
WHERE id = 1

/*4. Eliminar el cliente con id=1 de la tabla "Clientes"*/
DELETE FROM public.Clientes
WHERE id = 1

/* 5. Crear una tabla llamada "Pedidos" con las columnas: id(entero, clave primaria), cliente_id (entero, clave externa referenciando a la tabla "Clientes"), producto (texto) y cantidad (entero). */
CREATE TABLE IF NOT EXISTS Pedidos(
    id SERIAL PRIMARY KEY,
    cliente_id INT,
    producto VARCHAR(255),
    cantidad INT
)

/* 6. Insertar un nuevo pedido en la tabla "Pedidos" con id=1, cliente_id=1, producto="Camiseta" y cantidad=2 */
INSERT INTO public.Pedidos (cliente_id, producto, cantidad)
VALUES (1, 'Camiseta', 2)

/* 7. Actualizar la cantidad del pedido con id=1 a 3 */
UPDATE public.Pedidos
SET cantidad = 3
WHERE id = 1

/* 8. Eliminar el pedido con id=1 de la tabla "Pedidos" */
DELETE FROM public.Pedidos 
WHERE id = 1

/*  9. Crear una tabla llamada "Productos" con las columnas: id (entero, clave primaria), nombre (texto) y precio (decimal) */
CREATE TABLE IF NOT EXISTS Productos(
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(255),
    precio decimal
)

/* 10. Insertar varios productos en la tabla "Productos" con diferentes valores. */ 
INSERT INTO public.Productos (nombre, precio)
VALUES  ('Camiseta', 19.99),
        ('Pantalón', 25.95),
        ('Abrigo', 55.99)

/* 11. Consultar todos los clientes de la tabla "Clientes" */
SELECT * FROM public.Clientes 

/* 12. Consultar todos los pedidos de la tabla "Pedidos" junto con los nombres de los clientes correspondientes */
SELECT public.Clientes.nombre, public.Pedidos.producto
FROM public.Clientes 
INNER JOIN public.Pedidos
ON public.Clientes.id = public.Pedidos.cliente_id

/* 13. Consultar todos los productos de la tabla "Productos" cuyo precio sea mayor a $50 */
SELECT * FROM public.Productos
WHERE precio > 50 

/* 14. Consultar los pedidos de la tabla "Pedidos" que tengan una cantidad mayor o igual a 5 */
SELECT * FROM public.Pedidos
WHERE cantidad >= 5

/* 15. Consultar los clientes de la tabla "Clientes" cuyo nombre empiece con la letra "A" */ 
SELECT * FROM public.Clientes
WHERE nombre = 'A%'

/* 16. Realizar una consulta que muestre el nombre del cliente y el total de pedidos realizados por cada cliente */
SELECT 
    Clientes.nombre AS nombre_cliente,
    COUNT(Pedidos.id) AS total_pedidos
FROM Clientes 
LEFT JOIN Pedidos 
ON Clientes.id = Pedidos.cliente_id
GROUP BY Clientes.id, Clientes.nombre 

/* 17. Realizar una consulta que muestre el nombre del producto y la cantidad total de pedidos de ese producto */ 
SELECT 
    Productos.nombre AS nombre_producto,
    SUM (Pedidos.cantidad) AS total_cantidad
FROM Pedidos
INNER JOIN Productos 
ON Pedidos.producto = Productos.nombre
GROUP BY Productos.id, Productos.nombre 

/* 18. Agregar una columna llamada "fecha" a la tabla "Pedidos" de tipo fecha */
ALTER TABLE Pedidos
ADD COLUMN fecha DATE 

/* 19. Agrega una clave externa a la tabla "Pedidos" que haga referencia a la tabla "Productos" en la columna "producto" */
ALTER TABLE Pedidos
ADD CONSTRAINT fk_producto
FOREIGN KEY (producto) REFERENCES Productos(id)

/* 20. Realizar una consulta que muestre los nombres de los clientes, los nombres de los productos y las cantidades de los pedidos donde coincida la clave externa */ 
SELECT  
    Clientes.nombre AS nombre_cliente,
    Productos.nombre AS nombre_producto,
    Pedidos.cantidad
FROM Pedidos
INNER JOIN Clientes 
ON Pedidos.cliente_id = Clientes.id
INNER JOIN Productos
ON Pedidos.producto = Productos.id




