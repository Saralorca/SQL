/* ## Ejercicio 2
1. Crea una base de datos llamada "MiBaseDeDatos" 
2. Crear una tabla llamada 'Usuarios' con las columnas: id (entero, clave primaria), nombre (texto) y edad (entero). */
CREATE TABLE Usuarios(
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    edad INT
)

/*3. Inserta dos registros en la tabla "Usuarios" */ 
INSERT INTO public.Usuarios (nombre, edad)
VALUES  ('Juan', 25),
        ('María', 30)

/* 4. Actualiza la edad de un usuario en la tabla "Usuarios" */
UPDATE public.Usuarios
SET edad = 28
WHERE id = 2

/* 5. Elimina un usuario de la tabla "Usuarios" */ 
DELETE FROM public.Usuarios
WHERE id = 2 

/* Nivel difícil
1. Crea una tabla llamada "Ciudades" con las columnas "id" (entero, clave primaria), "nombre" (texto) y "pais" (texto) */
CREATE TABLE Ciudades(
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(255),
	pais VARCHAR(255)
)

/* 2. Inserta al menos tres registros en la tabla "Ciudades" */
INSERT INTO public.Ciudades (nombre, pais)
VALUES  ('París', 'Francia'),
        ('Madrid', 'España'),
        ('Berlín', 'Alemania')

/* 3. Crea una foreign key en la tabla "Usuarios" que se relacione con la columna "id" de la tabla "Ciudades" */
ALTER TABLE public.usuarios
ADD COLUMN ciudad_id INTEGER;

ALTER TABLE public.usuarios
ADD CONSTRAINT fk_ciudad_id
FOREIGN KEY (ciudad_id) REFERENCES public.ciudades(id)

/* 4. Realiza una consulta que muestre los nombres de los usuarios junto con el nombre de su ciudad y país (utiliza un LEFT JOIN) */ 
SELECT 
    Usuarios.nombre AS usuario,
    Ciudades.nombre AS ciudad,
    Ciudades.pais
FROM Usuarios
LEFT JOIN Ciudades ON Usuarios.ciudad_id = Ciudades.id


/* 5. Realiza una consulta que muestre solo los usuarios que tienen una ciudad asociada (utiliza un INNER JOIN) */ 
SELECT 
	Usuarios.nombre AS usuario,
	Ciudades.nombre AS ciudad,
	Ciudades.pais AS pais
FROM Usuarios
INNER JOIN Ciudades ON Usuarios.ciudad_id = Ciudades.id